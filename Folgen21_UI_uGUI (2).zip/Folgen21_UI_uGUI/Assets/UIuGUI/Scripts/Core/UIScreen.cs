using UnityEngine;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Clase base de todos los controladores de pantalla del paquete uGUI.
    /// Cada pantalla es un prefab con su propio Canvas (Screen Space - Overlay);
    /// Mostrar/ocultar conmuta el Canvas (el GameObject permanece activo para
    /// que Awake y las referencias de los controladores siempre existan).
    /// </summary>
    [RequireComponent(typeof(Canvas))]
    public abstract class UIScreen : MonoBehaviour
    {
        [Tooltip("Si esta activo, la pantalla se muestra automaticamente al iniciar la escena.")]
        public bool mostrarAlIniciar = false;

        /// <summary>Indica si la pantalla esta visible actualmente.</summary>
        public bool Visible { get; private set; }

        protected virtual void Awake()
        {
            Mostrar(mostrarAlIniciar);
        }

        /// <summary>Muestra u oculta la pantalla.</summary>
        public virtual void Mostrar(bool visible)
        {
            Visible = visible;
            Canvas canvas = GetComponent<Canvas>();
            if (canvas != null) canvas.enabled = visible;

            CanvasGroup grupo = GetComponent<CanvasGroup>();
            if (grupo != null)
            {
                grupo.blocksRaycasts = visible;
                grupo.interactable = visible;
            }

            if (visible) OnMostrado();
        }

        /// <summary>Se llama cada vez que la pantalla pasa a visible.</summary>
        protected virtual void OnMostrado() { }

        /// <summary>
        /// Busca un componente en la ruta relativa "Hijo/Nieto/..." del prefab.
        /// UIFactory nombra todos los elementos; aqui se recuperan por nombre.
        /// </summary>
        protected T Hijo<T>(string ruta) where T : Component
        {
            Transform t = transform.Find(ruta);
            if (t == null)
            {
                Debug.LogError($"[Folgen21] '{name}': no se encontro el elemento '{ruta}'. " +
                               "Ejecuta Tools → Folgen 21 UI (uGUI) → 1. Instalar todo para regenerar los prefabs.");
                return null;
            }
            return t.GetComponent<T>();
        }
    }
}
