using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui.EditorTools
{
    /// <summary>
    /// Fabrica de las 5 pantallas de Folgen 21 en uGUI (Unity UI).
    /// Construye la jerarquia completa (Canvas, Images, Texts, Buttons, Sliders...)
    /// con el estilo cyberpunk del juego y la guarda como prefabs editables.
    /// La llama FolgenUIInstaller; tambien puedes usarla para regenerar pantallas.
    /// </summary>
    public static class UIFactory
    {
        public const string RaizAssets = "Assets/UIuGUI";
        public const string RaizArt = RaizAssets + "/Art";
        public const string RaizFonts = RaizAssets + "/Fonts";
        public const string RaizPrefabs = RaizAssets + "/Prefabs";

        private static Font _orbitron700, _orbitron900, _rajdhani500, _rajdhani600;

        // ================= PUNTO DE ENTRADA =================

        /// <summary>Construye las 5 pantallas y las guarda como prefabs. Devuelve las rutas.</summary>
        public static string[] ConstruirYGuardarTodo()
        {
            CargarFuentes();
            Directory.CreateDirectory(RaizPrefabs);

            string[] rutas = new string[5];
            rutas[0] = GuardarPrefab(ConstruirMenuPrincipal(), "PantallaMenuPrincipal.prefab");
            rutas[1] = GuardarPrefab(ConstruirHUD(), "PantallaHUD.prefab");
            rutas[2] = GuardarPrefab(ConstruirPausa(), "PantallaPausa.prefab");
            rutas[3] = GuardarPrefab(ConstruirAjustes(), "PantallaAjustes.prefab");
            rutas[4] = GuardarPrefab(ConstruirCarga(), "PantallaCarga.prefab");
            return rutas;
        }

        private static string GuardarPrefab(GameObject pantalla, string nombreArchivo)
        {
            string ruta = $"{RaizPrefabs}/{nombreArchivo}";
            PrefabUtility.SaveAsPrefabAsset(pantalla, ruta);
            Object.DestroyImmediate(pantalla);
            Debug.Log($"[Folgen21] Prefab creado: {ruta}");
            return ruta;
        }

        private static void CargarFuentes()
        {
            _orbitron700 = AssetDatabase.LoadAssetAtPath<Font>($"{RaizFonts}/Orbitron-700.ttf");
            _orbitron900 = AssetDatabase.LoadAssetAtPath<Font>($"{RaizFonts}/Orbitron-900.ttf");
            _rajdhani500 = AssetDatabase.LoadAssetAtPath<Font>($"{RaizFonts}/Rajdhani-500.ttf");
            _rajdhani600 = AssetDatabase.LoadAssetAtPath<Font>($"{RaizFonts}/Rajdhani-600.ttf");
        }

        private static Font Titulo(int peso = 700) => peso >= 900 ? _orbitron900 : _orbitron700;
        private static Font Texto(int peso = 500) => peso >= 600 ? _rajdhani600 : _rajdhani500;

        private static Sprite Sp(string nombre)
        {
            Sprite s = AssetDatabase.LoadAssetAtPath<Sprite>($"{RaizArt}/{nombre}");
            if (s == null) Debug.LogError($"[Folgen21] No se encontro el sprite {RaizArt}/{nombre}. Ejecuta primero el instalador.");
            return s;
        }

        // ================= HELPERS DE CONSTRUCCION =================

        private static GameObject Nuevo(string nombre, Transform padre)
        {
            GameObject go = new GameObject(nombre, typeof(RectTransform));
            go.transform.SetParent(padre, false);
            return go;
        }

        /// <summary>Ancla en un punto (esquina) con pivote igual; pos = offset desde el ancla.</summary>
        private static RectTransform RT(GameObject go, Vector2 ancla, Vector2 pos, Vector2 size)
        {
            var rt = (RectTransform)go.transform;
            rt.anchorMin = ancla;
            rt.anchorMax = ancla;
            rt.pivot = ancla;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        /// <summary>Estira el rect al padre completo (con margen).</summary>
        private static RectTransform Estirar(GameObject go, float margen = 0f)
        {
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(margen, margen);
            rt.offsetMax = new Vector2(-margen, -margen);
            return rt;
        }

        private static Image Imagen(GameObject go, Sprite sprite, Color color, bool raycast = false)
        {
            Image img = go.GetComponent<Image>();
            if (img == null) img = go.AddComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            img.raycastTarget = raycast;
            img.type = Image.Type.Simple;
            return img;
        }

        private static Image Imagen9(GameObject go, Sprite sprite, Color color, bool raycast = false)
        {
            Image img = Imagen(go, sprite, color, raycast);
            img.type = Image.Type.Sliced;
            img.fillCenter = true;
            return img;
        }

        private static Text Texto(GameObject go, string contenido, Font fuente, int tamano, Color color,
                                  TextAnchor alineacion = TextAnchor.MiddleLeft)
        {
            Text t = go.GetComponent<Text>();
            if (t == null) t = go.AddComponent<Text>();
            t.text = contenido;
            t.font = fuente;
            t.fontSize = tamano;
            t.color = color;
            t.alignment = alineacion;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            return t;
        }

        /// <summary>Inserta un espacio entre caracteres y doble entre palabras (simula letter-spacing).</summary>
        private static string Espaciar(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s)
            {
                if (c == ' ') { sb.Append("  "); continue; }
                if (sb.Length > 0 && sb[sb.Length - 1] != ' ') sb.Append(' ');
                sb.Append(c);
            }
            return sb.ToString();
        }

        /// <summary>Boton con marco 9-slice, texto centrado e icono opcional a la izquierda.</summary>
        private static Button Boton(Transform padre, string nombre, string texto, Font fuenteTexto,
                                    float tamanoTexto, Color colorTexto, Sprite marcoIdle, Sprite marcoHover,
                                    Vector2 ancla, Vector2 pos, Vector2 size, Sprite icono = null,
                                    float iconoX = 0f, TextAnchor alineacionTexto = TextAnchor.MiddleCenter)
        {
            GameObject go = Nuevo(nombre, padre);
            RT(go, ancla, pos, size);
            Imagen9(go, marcoIdle, FolgenColores.Blanco, raycast: true);

            Button btn = go.AddComponent<Button>();
            btn.transition = Selectable.Transition.SpriteSwap;
            var estado = new Button.SpriteState();
            if (marcoHover != null)
            {
                estado.highlightedSprite = marcoHover;
                estado.pressedSprite = marcoHover;
            }
            btn.spriteState = estado;

            if (icono != null)
            {
                GameObject gi = Nuevo("Icono", go.transform);
                RT(gi, new Vector2(0.5f, 0.5f), new Vector2(iconoX, 0f), new Vector2(34f, 34f));
                Imagen(gi, icono, FolgenColores.Blanco);
            }

            if (!string.IsNullOrEmpty(texto))
            {
                GameObject gt = Nuevo("Texto", go.transform);
                RectTransform rt;
                if (icono != null)
                {
                    // con icono: el texto arranca a la derecha del icono y se alinea a la izquierda
                    rt = RT(gt, new Vector2(0.5f, 0.5f), new Vector2(iconoX + 31f, 0f),
                            new Vector2(size.x * 0.5f - (iconoX + 31f) - 24f, 44f));
                    rt.pivot = new Vector2(0f, 0.5f);
                    Text tIzq = Texto(gt, texto, fuenteTexto, Mathf.RoundToInt(tamanoTexto), colorTexto, TextAnchor.MiddleLeft);
                    tIzq.horizontalOverflow = HorizontalWrapMode.Overflow;
                }
                else
                {
                    rt = RT(gt, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(size.x - 40f, 44f));
                    Text tCentro = Texto(gt, texto, fuenteTexto, Mathf.RoundToInt(tamanoTexto), colorTexto, alineacionTexto);
                    tCentro.horizontalOverflow = HorizontalWrapMode.Overflow;
                }
            }
            return btn;
        }

        /// <summary>Slider horizontal estilo Folgen (track oscuro, relleno cian, tirador circular).</summary>
        private static Slider SliderBarra(Transform padre, string nombre, Vector2 ancla, Vector2 pos,
                                          Vector2 size, float valorInicial, float min = 0f, float max = 1f)
        {
            GameObject go = Nuevo(nombre, padre);
            RT(go, ancla, pos, size);

            GameObject fondo = Nuevo("Fondo", go.transform);
            var rtFondo = (RectTransform)fondo.transform;
            rtFondo.anchorMin = Vector2.zero; rtFondo.anchorMax = Vector2.one;
            rtFondo.offsetMin = Vector2.zero; rtFondo.offsetMax = Vector2.zero;
            Imagen9(fondo, Sp("cuadro.png"), new Color(0.10f, 0.06f, 0.18f, 0.94f));

            GameObject areaFill = Nuevo("AreaFill", go.transform);
            var rtArea = (RectTransform)areaFill.transform;
            rtArea.anchorMin = Vector2.zero; rtArea.anchorMax = Vector2.one;
            rtArea.offsetMin = new Vector2(4f, 4f); rtArea.offsetMax = new Vector2(-4f, -4f);

            GameObject fill = Nuevo("Fill", areaFill.transform);
            var rtFill = (RectTransform)fill.transform;
            rtFill.anchorMin = new Vector2(0f, 0f);
            rtFill.anchorMax = new Vector2(0f, 1f);
            rtFill.offsetMin = Vector2.zero; rtFill.offsetMax = Vector2.zero;
            Imagen(fill, Sp("bar_fill_cian.png"), FolgenColores.Blanco);

            GameObject areaHandle = Nuevo("AreaHandle", go.transform);
            var rtAH = (RectTransform)areaHandle.transform;
            rtAH.anchorMin = Vector2.zero; rtAH.anchorMax = Vector2.one;
            rtAH.offsetMin = new Vector2(12f, -6f); rtAH.offsetMax = new Vector2(-12f, 6f);

            GameObject handle = Nuevo("Handle", areaHandle.transform);
            var rtH = (RectTransform)handle.transform;
            rtH.anchorMin = new Vector2(0f, 0f);
            rtH.anchorMax = new Vector2(0f, 1f);
            rtH.offsetMin = new Vector2(-12f, 0f);
            rtH.sizeDelta = new Vector2(24f, 0f);
            Image imgHandle = Imagen(handle, Sp("circle.png"), FolgenColores.Cyan, raycast: true);

            Slider s = go.AddComponent<Slider>();
            s.fillRect = (RectTransform)fill.transform;
            s.handleRect = (RectTransform)handle.transform;
            s.targetGraphic = imgHandle;
            s.direction = Slider.Direction.LeftToRight;
            s.minValue = min;
            s.maxValue = max;
            s.value = valorInicial;
            return s;
        }

        /// <summary>Casilla de verificacion estilo Folgen.</summary>
        private static Toggle Casilla(Transform padre, string nombre, Vector2 ancla, Vector2 pos, Vector2 size, bool valor)
        {
            GameObject go = Nuevo(nombre, padre);
            RT(go, ancla, pos, size);

            GameObject fondo = Nuevo("Fondo", go.transform);
            Estirar(fondo);
            Image imgFondo = Imagen9(fondo, Sp("cuadro.png"), FolgenColores.ConAlfa(FolgenColores.PanelBorde, 0.9f), raycast: true);

            GameObject marca = Nuevo("Marca", go.transform);
            RT(marca, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(28f, 28f));
            Image imgMarca = Imagen(marca, Sp("circle.png"), FolgenColores.Cyan);

            Toggle t = go.AddComponent<Toggle>();
            t.targetGraphic = imgFondo;
            t.graphic = imgMarca;
            t.toggleTransition = Toggle.ToggleTransition.Fade;
            t.SetIsOnWithoutNotify(valor);
            return t;
        }

        /// <summary>Fila de controles del HUD: teclas cuadradas + etiqueta.</summary>
        private static void FilaControles(Transform padre, string nombre, Vector2 pos, string[] teclas,
                                          string etiqueta, float anchoEtiquetaDesde)
        {
            GameObject fila = Nuevo(nombre, padre);
            RT(fila, new Vector2(0f, 1f), pos, new Vector2(600f, 46f));

            float x = 0f;
            foreach (string tecla in teclas)
            {
                float ancho = tecla.Length > 1 ? 20f + tecla.Length * 18f : 46f;
                GameObject cap = Nuevo("Tecla_" + tecla, fila.transform);
                RT(cap, new Vector2(0f, 0.5f), new Vector2(x, 0f), new Vector2(ancho, 46f));
                Imagen9(cap, Sp("cuadro.png"), FolgenColores.PanelTransp(0.92f));

                GameObject gt = Nuevo("T", cap.transform);
                RT(gt, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(ancho, 34f));
                Texto(gt, tecla, Texto(600), 20, FolgenColores.Blanco, TextAnchor.MiddleCenter);
                x += ancho + 6f;
            }

            GameObject gl = Nuevo("Etiqueta", fila.transform);
            RT(gl, new Vector2(0f, 0.5f), new Vector2(anchoEtiquetaDesde, 0f), new Vector2(320f, 46f));
            Texto(gl, etiqueta, Texto(500), 22, FolgenColores.ConAlfa(FolgenColores.Blanco, 0.94f), TextAnchor.MiddleLeft);
        }

        private static Canvas BasePantalla(string nombre, int orden)
        {
            GameObject go = new GameObject(nombre, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;

            Canvas canvas = go.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = orden;

            CanvasScaler scaler = go.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;
            return canvas;
        }

        private static void AcentoIzquierdo(GameObject caja, Color color)
        {
            GameObject acento = Nuevo("Acento", caja.transform);
            var rt = (RectTransform)acento.transform;
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(4f, 0f);
            Imagen(acento, null, color);
        }

        // ================= 1. MENU PRINCIPAL =================

        public static GameObject ConstruirMenuPrincipal()
        {
            Canvas root = BasePantalla("PantallaMenuPrincipal", 10);
            root.gameObject.AddComponent<MainMenuController>();

            Imagen(root.gameObject, Sp("mainmenu_bg.png"), FolgenColores.Blanco);
            Imagen(Nuevo("Vineta", root.transform), Sp("vigneta.png"), FolgenColores.Blanco);

            GameObject version = Nuevo("LblVersion", root.transform);
            RT(version, new Vector2(0f, 1f), new Vector2(28f, -22f), new Vector2(500f, 32f));
            Texto(version, "FOLGEN 21 v1.0.0", Texto(500), 22, FolgenColores.ConAlfa(FolgenColores.Blanco, 0.78f));

            Boton(root.transform, "btnEngranaje", "", Texto(600), 0, FolgenColores.Blanco,
                  Sp("icon_gear_button.png"), null,
                  new Vector2(1f, 1f), new Vector2(-30f, -26f), new Vector2(64f, 64f));

            GameObject centro = Nuevo("Centro", root.transform);
            Estirar(centro);

            GameObject logo = Nuevo("LblLogo", centro.transform);
            RT(logo, new Vector2(0.5f, 0.5f), new Vector2(0f, 130f), new Vector2(1400f, 160f));
            Text tLogo = Texto(logo, "FOLGEN <color=#FF2D9B>21</color>", Titulo(900), 116, FolgenColores.Blanco, TextAnchor.MiddleCenter);
            tLogo.alignment = TextAnchor.LowerCenter;

            GameObject sub = Nuevo("LblSub", centro.transform);
            RT(sub, new Vector2(0.5f, 0.5f), new Vector2(0f, 42f), new Vector2(1100f, 48f));
            Texto(sub, Espaciar("FUERA DEL PRONÓSTICO"), Texto(600), 34, FolgenColores.Blanco, TextAnchor.MiddleCenter);

            GameObject subrayado = Nuevo("Subrayado", centro.transform);
            RT(subrayado, new Vector2(0.5f, 0.5f), new Vector2(0f, -2f), new Vector2(620f, 6f));
            Image imgSub = Imagen(subrayado, Sp("bar_acento.png"), FolgenColores.Blanco);
            imgSub.rectTransform.localEulerAngles = new Vector3(0f, 0f, 1.2f);

            GameObject botones = Nuevo("Botones", centro.transform);
            RT(botones, new Vector2(0.5f, 0.5f), new Vector2(0f, -253f), new Vector2(760f, 406f));

            Sprite marcoIdle = Sp("btn_frame_idle.png");
            Sprite marcoHover = Sp("btn_frame_hover.png");
            string[][] datos =
            {
                new[] { "btnNuevaPartida", "NUEVA PARTIDA", "icon_play.png" },
                new[] { "btnContinuar",    "CONTINUAR",     "icon_refresh.png" },
                new[] { "btnAjustes",      "AJUSTES",       "icon_gear.png" },
                new[] { "btnSalir",        "SALIR",         "icon_exit.png" },
            };
            for (int i = 0; i < datos.Length; i++)
            {
                Boton(botones.transform, datos[i][0], Espaciar(datos[i][1]), Texto(600), 30f, FolgenColores.Blanco,
                      marcoIdle, marcoHover, new Vector2(0.5f, 1f), new Vector2(0f, -i * 106f), new Vector2(760f, 88f),
                      Sp(datos[i][2]), -180f);
            }

            GameObject slogan = Nuevo("Slogan", root.transform);
            RT(slogan, new Vector2(0.5f, 0f), new Vector2(0f, 26f), new Vector2(1100f, 40f));
            GameObject gl = Nuevo("Texto", slogan.transform);
            RT(gl, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(900f, 36f));
            Texto(gl, Espaciar("Enfrenta tu destino en un mundo sin reglas"), Texto(500), 27,
                  FolgenColores.ConAlfa(HexColor("E9E2F5"), 0.92f), TextAnchor.MiddleCenter);
            for (int i = 0; i < 2; i++)
            {
                GameObject linea = Nuevo(i == 0 ? "LineaIzq" : "LineaDer", slogan.transform);
                RT(linea, new Vector2(0.5f, 0.5f), new Vector2(i == 0 ? -492f : 492f, 0f), new Vector2(140f, 2f));
                Imagen(linea, null, FolgenColores.ConAlfa(FolgenColores.Blanco, 0.35f));
            }

            GameObject marca = Nuevo("LblMarcaAgua", root.transform);
            RT(marca, new Vector2(1f, 0f), new Vector2(-26f, -14f), new Vector2(320f, 200f));
            Text tMarca = Texto(marca, "21", Titulo(900), 150,
                                FolgenColores.ConAlfa(FolgenColores.Magenta, 0.16f), TextAnchor.LowerRight);
            tMarca.fontStyle = FontStyle.Bold;

            return root.gameObject;
        }

        // ================= 2. HUD DE COMBATE =================

        public static GameObject ConstruirHUD()
        {
            Canvas root = BasePantalla("PantallaHUD", 0);
            root.gameObject.AddComponent<GameplayHUDController>();

            // ----- jugador (arriba izquierda) -----
            GameObject jugador = Nuevo("Jugador", root.transform);
            RT(jugador, new Vector2(0f, 1f), new Vector2(28f, -26f), new Vector2(520f, 130f));

            GameObject retrato = Nuevo("Retrato", jugador.transform);
            RT(retrato, new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(108f, 108f));
            GameObject imgRetrato = Nuevo("ImgRetrato", retrato.transform);
            RT(imgRetrato, new Vector2(0f, 1f), new Vector2(8f, -8f), new Vector2(92f, 92f));
            Imagen(imgRetrato, Sp("portrait_jhoel.png"), FolgenColores.Blanco);
            GameObject marco = Nuevo("Marco", retrato.transform);
            RT(marco, new Vector2(0f, 1f), new Vector2(0f, 0f), new Vector2(108f, 108f));
            Imagen(marco, Sp("portrait_frame.png"), FolgenColores.Blanco);

            GameObject nivelFondo = Nuevo("NivelFondo", retrato.transform);
            RT(nivelFondo, new Vector2(0f, 0f), new Vector2(7f, 7f), new Vector2(30f, 30f));
            Imagen(nivelFondo, Sp("circle.png"), FolgenColores.Vida);
            GameObject nivel = Nuevo("Nivel", retrato.transform);
            RT(nivel, new Vector2(0f, 0f), new Vector2(7f, 7f), new Vector2(30f, 30f));
            Texto(nivel, "1", Titulo(700), 17, FolgenColores.Blanco, TextAnchor.MiddleCenter);

            GameObject datos = Nuevo("Datos", jugador.transform);
            RT(datos, new Vector2(0f, 0f), new Vector2(122f, 0f), new Vector2(400f, 130f));

            GameObject nombre = Nuevo("LblNombre", datos.transform);
            RT(nombre, new Vector2(0f, 1f), new Vector2(0f, -2f), new Vector2(400f, 40f));
            Texto(nombre, "JHOEL", Titulo(700), 27, FolgenColores.Blanco, TextAnchor.MiddleLeft);

            CrearBarra(datos.transform, "BarraVida", -52f, 15f, Sp("bar_fill_rojo.png"));
            CrearBarra(datos.transform, "BarraEnergia", -74f, 10f, Sp("bar_fill_azul.png"));

            // ----- combate / objetivo (bajo el retrato) -----
            GameObject mision = Nuevo("Mision", root.transform);
            RT(mision, new Vector2(0f, 1f), new Vector2(28f, -168f), new Vector2(640f, 92f));
            Imagen9(mision, Sp("cuadro.png"), FolgenColores.PanelTransp(0.82f));
            AcentoIzquierdo(mision, FolgenColores.Oro);

            GameObject mi = Nuevo("Icono", mision.transform);
            RT(mi, new Vector2(0f, 0.5f), new Vector2(16f, 0f), new Vector2(42f, 42f));
            Imagen(mi, Sp("diamond_gold.png"), FolgenColores.Blanco);

            GameObject mt = Nuevo("LblTitulo", mision.transform);
            RT(mt, new Vector2(0f, 1f), new Vector2(74f, -10f), new Vector2(550f, 32f));
            Texto(mt, "COMBATE: MOVIMIENTO", Titulo(700), 22, FolgenColores.Oro, TextAnchor.MiddleLeft);

            GameObject mo = Nuevo("LblObjetivo", mision.transform);
            RT(mo, new Vector2(0f, 1f), new Vector2(74f, -48f), new Vector2(550f, 36f));
            Texto(mo, "Camina y esprinta hacia tu rival (45 m)", Texto(500), 23, FolgenColores.Blanco, TextAnchor.MiddleLeft);

            // ----- controles: caminar, sprintar, habilidades -----
            GameObject controles = Nuevo("Controles", root.transform);
            RT(controles, new Vector2(0f, 0f), new Vector2(28f, 40f), new Vector2(600f, 170f));
            FilaControles(controles.transform, "FilaCaminar", new Vector2(0f, -24f), new[] { "W", "A", "S", "D" }, "Caminar", 216f);
            FilaControles(controles.transform, "FilaSprintar", new Vector2(0f, -80f), new[] { "SHIFT" }, "Sprintar", 124f);
            FilaControles(controles.transform, "FilaHabilidades", new Vector2(0f, -136f), new[] { "Q", "E", "R" }, "Habilidades", 164f);

            // ----- minimapa circular -----
            GameObject minimapa = Nuevo("Minimapa", root.transform);
            RT(minimapa, new Vector2(1f, 1f), new Vector2(-28f, -26f), new Vector2(200f, 200f));
            Imagen(minimapa, Sp("circle.png"), new Color(0.08f, 0.05f, 0.14f, 0.88f));
            Mask mascara = minimapa.AddComponent<Mask>();
            mascara.showMaskGraphic = true;

            GameObject mapa = Nuevo("Mapa", minimapa.transform);
            Estirar(mapa);
            RawImage raw = mapa.AddComponent<RawImage>();
            raw.raycastTarget = false;
            raw.enabled = false;

            GameObject norte = Nuevo("LblNorte", minimapa.transform);
            RT(norte, new Vector2(0.5f, 1f), new Vector2(0f, -3f), new Vector2(60f, 28f));
            Texto(norte, "N", Titulo(700), 21, FolgenColores.ConAlfa(FolgenColores.Blanco, 0.88f), TextAnchor.MiddleCenter);

            GameObject flecha = Nuevo("Flecha", minimapa.transform);
            RT(flecha, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(34f, 34f));
            Imagen(flecha, Sp("player_arrow.png"), FolgenColores.Blanco);

            GameObject marcador = Nuevo("Marcador", minimapa.transform);
            RT(marcador, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(30f, 30f));
            Imagen(marcador, Sp("minimap_marker.png"), FolgenColores.Blanco);

            GameObject borde = Nuevo("Borde", minimapa.transform);
            Estirar(borde);
            Imagen(borde, Sp("circle_ring.png"), FolgenColores.ConAlfa(FolgenColores.Blanco, 0.28f));

            // ----- caja de consejos (derecha) -----
            GameObject tip = Nuevo("Tip", root.transform);
            RT(tip, new Vector2(1f, 1f), new Vector2(-30f, -252f), new Vector2(460f, 60f));
            Imagen9(tip, Sp("cuadro.png"), FolgenColores.PanelTransp(0.85f));
            AcentoIzquierdo(tip, FolgenColores.Magenta);
            tip.AddComponent<CanvasGroup>();

            GameObject iconoTip = Nuevo("Icono", tip.transform);
            RT(iconoTip, new Vector2(0f, 0.5f), new Vector2(18f, 0f), new Vector2(27f, 27f));
            Imagen(iconoTip, Sp("icon_warn.png"), FolgenColores.Blanco);

            GameObject textoTip = Nuevo("LblTip", tip.transform);
            RT(textoTip, new Vector2(0f, 0f), new Vector2(58f, 0f), new Vector2(388f, 60f));
            Text tTip = Texto(textoTip, "Acércate a tu rival y usa tus habilidades.", Texto(500), 22,
                              FolgenColores.Blanco, TextAnchor.MiddleLeft);
            tTip.horizontalOverflow = HorizontalWrapMode.Wrap;

            // ----- marcador del rival en el mundo -----
            GameObject marcadorMundo = Nuevo("MarcadorMundo", root.transform);
            RT(marcadorMundo, new Vector2(0.5f, 0.5f), new Vector2(0f, 0f), new Vector2(160f, 80f));

            GameObject diamante = Nuevo("Diamante", marcadorMundo.transform);
            RT(diamante, new Vector2(0.5f, 1f), new Vector2(0f, -10f), new Vector2(36f, 36f));
            Imagen(diamante, Sp("diamond_gold.png"), FolgenColores.Blanco);

            GameObject distancia = Nuevo("LblDistancia", marcadorMundo.transform);
            RT(distancia, new Vector2(0.5f, 1f), new Vector2(0f, -52f), new Vector2(160f, 30f));
            Texto(distancia, "45 m", Texto(600), 24, FolgenColores.Blanco, TextAnchor.MiddleCenter);

            // ----- habilidades Q / E / R / I -----
            GameObject skills = Nuevo("Skills", root.transform);
            RT(skills, new Vector2(1f, 0f), new Vector2(-30f, 26f), new Vector2(372f, 112f));

            string[] frames = { "skill_frame_q.png", "skill_frame_e.png", "skill_frame_r.png", "skill_frame_i.png" };
            string[] iconos = { "icon_skill_q.png", "icon_skill_e.png", "icon_skill_r.png", "icon_item.png" };
            string[] teclas = { "Q", "E", "R", "I" };
            for (int i = 0; i < 4; i++)
            {
                GameObject slot = Nuevo($"Slot{i}", skills.transform);
                RT(slot, new Vector2(0f, 1f), new Vector2(i * 98f, 0f), new Vector2(78f, 112f));

                GameObject marcoS = Nuevo("Marco", slot.transform);
                RT(marcoS, new Vector2(0.5f, 1f), new Vector2(0f, 0f), new Vector2(78f, 78f));
                Imagen(marcoS, Sp(frames[i]), FolgenColores.Blanco);

                GameObject icono = Nuevo("Icono", slot.transform);
                RT(icono, new Vector2(0.5f, 1f), new Vector2(0f, -39f), new Vector2(40f, 40f));
                Imagen(icono, Sp(iconos[i]), FolgenColores.Blanco);

                GameObject enf = Nuevo("Enfriamiento", slot.transform);
                RT(enf, new Vector2(0.5f, 1f), new Vector2(0f, -39f), new Vector2(40f, 40f));
                Image imgEnf = Imagen(enf, Sp("cuadro.png"), new Color(0.03f, 0.016f, 0.06f, 0.8f));
                imgEnf.type = Image.Type.Filled;
                imgEnf.fillMethod = Image.FillMethod.Vertical;
                imgEnf.fillOrigin = (int)Image.OriginVertical.Top;
                imgEnf.fillAmount = 0f;

                GameObject cant = Nuevo("Cantidad", slot.transform);
                RT(cant, new Vector2(1f, 1f), new Vector2(-6f, -2f), new Vector2(30f, 24f));
                Texto(cant, "", Texto(600), 20, FolgenColores.Blanco, TextAnchor.UpperRight);

                GameObject tecla = Nuevo("Tecla", slot.transform);
                RT(tecla, new Vector2(0.5f, 1f), new Vector2(0f, -84f), new Vector2(78f, 26f));
                Texto(tecla, teclas[i], Titulo(700), 22, FolgenColores.Blanco, TextAnchor.MiddleCenter);
            }

            return root.gameObject;
        }

        private static void CrearBarra(Transform padre, string nombre, float y, float alto, Sprite relleno)
        {
            GameObject barra = Nuevo(nombre, padre);
            RT(barra, new Vector2(0f, 1f), new Vector2(0f, y), new Vector2(270f, alto));
            Imagen9(barra, Sp("cuadro.png"), new Color(0.10f, 0.06f, 0.18f, 0.9f));

            GameObject fill = Nuevo("Fill", barra.transform);
            var rt = (RectTransform)fill.transform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0f, 0.5f);
            rt.offsetMin = new Vector2(2f, 2f);
            rt.offsetMax = new Vector2(-2f, -2f);
            Image img = Imagen(fill, relleno, FolgenColores.Blanco);
            img.type = Image.Type.Filled;
            img.fillMethod = Image.FillMethod.Horizontal;
            img.fillAmount = 1f;
        }

        // ================= 3. PAUSA =================

        public static GameObject ConstruirPausa()
        {
            Canvas root = BasePantalla("PantallaPausa", 20);
            root.gameObject.AddComponent<PauseMenuController>();
            Imagen(root.gameObject, null, new Color(0.035f, 0.016f, 0.066f, 0.72f), raycast: true);

            GameObject titulo = Nuevo("LblTitulo", root.transform);
            RT(titulo, new Vector2(0.5f, 0.5f), new Vector2(0f, 210f), new Vector2(600f, 120f));
            Texto(titulo, Espaciar("PAUSA"), Titulo(900), 96, FolgenColores.Blanco, TextAnchor.MiddleCenter);

            GameObject subrayado = Nuevo("Subrayado", root.transform);
            RT(subrayado, new Vector2(0.5f, 0.5f), new Vector2(0f, 140f), new Vector2(320f, 6f));
            Imagen(subrayado, Sp("bar_acento.png"), FolgenColores.Blanco);

            GameObject botones = Nuevo("Botones", root.transform);
            RT(botones, new Vector2(0.5f, 0.5f), new Vector2(0f, -60f), new Vector2(460f, 362f));

            Sprite marcoIdle = Sp("btn_frame_idle.png");
            Sprite marcoHover = Sp("btn_frame_hover.png");
            string[][] datos =
            {
                new[] { "btnContinuar",      "CONTINUAR",       "icon_play.png" },
                new[] { "btnAjustes",        "AJUSTES",         "icon_gear.png" },
                new[] { "btnMenuPrincipal",  "MENÚ PRINCIPAL",  "icon_refresh.png" },
                new[] { "btnSalir",          "SALIR",           "icon_exit.png" },
            };
            for (int i = 0; i < datos.Length; i++)
            {
                Boton(botones.transform, datos[i][0], Espaciar(datos[i][1]), Texto(600), 26f, FolgenColores.Blanco,
                      marcoIdle, marcoHover, new Vector2(0.5f, 1f), new Vector2(0f, -i * 96f), new Vector2(460f, 74f),
                      Sp(datos[i][2]), -140f);
            }

            return root.gameObject;
        }

        // ================= 4. AJUSTES =================

        public static GameObject ConstruirAjustes()
        {
            Canvas root = BasePantalla("PantallaAjustes", 25);
            root.gameObject.AddComponent<SettingsMenuController>();
            Imagen(root.gameObject, null, new Color(0.035f, 0.016f, 0.066f, 0.82f), raycast: true);

            GameObject panelBorde = Nuevo("PanelBorde", root.transform);
            RT(panelBorde, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(844f, 784f));
            Imagen9(panelBorde, Sp("cuadro.png"), FolgenColores.ConAlfa(FolgenColores.PanelBorde, 0.95f));

            GameObject panel = Nuevo("Panel", root.transform);
            RT(panel, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(836f, 776f));
            Imagen9(panel, Sp("cuadro.png"), new Color(0.086f, 0.047f, 0.149f, 0.96f));

            GameObject titulo = Nuevo("LblTitulo", panel.transform);
            RT(titulo, new Vector2(0.5f, 1f), new Vector2(0f, -52f), new Vector2(500f, 70f));
            Texto(titulo, Espaciar("AJUSTES"), Titulo(900), 54, FolgenColores.Blanco, TextAnchor.MiddleCenter);

            GameObject subrayado = Nuevo("Subrayado", panel.transform);
            RT(subrayado, new Vector2(0.5f, 1f), new Vector2(0f, -126f), new Vector2(300f, 5f));
            Imagen(subrayado, Sp("bar_acento.png"), FolgenColores.Blanco);

            GameObject filas = Nuevo("Filas", panel.transform);
            RT(filas, new Vector2(0.5f, 0.5f), new Vector2(0f, 30f), new Vector2(740f, 430f));

            string[][] filasDatos =
            {
                new[] { "FilaMusica",       "MÚSICA" },
                new[] { "FilaEfectos",      "EFECTOS" },
                new[] { "FilaSensibilidad", "SENSIBILIDAD" },
                new[] { "FilaCalidad",      "CALIDAD" },
                new[] { "FilaResolucion",   "RESOLUCIÓN" },
                new[] { "FilaPantalla",     "PANTALLA COMPLETA" },
            };
            for (int i = 0; i < filasDatos.Length; i++)
            {
                GameObject fila = Nuevo(filasDatos[i][0], filas.transform);
                RT(fila, new Vector2(0f, 1f), new Vector2(0f, -i * 70f), new Vector2(740f, 60f));

                GameObject etiq = Nuevo("Etiqueta", fila.transform);
                RT(etiq, new Vector2(0f, 0.5f), new Vector2(10f, 0f), new Vector2(280f, 40f));
                Texto(etiq, filasDatos[i][1], Texto(600), 26, FolgenColores.Blanco, TextAnchor.MiddleLeft);
            }

            // sliders (derecha de las 3 primeras filas)
            SliderBarra(filas.transform.Find("FilaMusica"), "Slider",
                        new Vector2(1f, 0.5f), new Vector2(-10f, 0f), new Vector2(400f, 20f), 0.8f);
            SliderBarra(filas.transform.Find("FilaEfectos"), "Slider",
                        new Vector2(1f, 0.5f), new Vector2(-10f, 0f), new Vector2(400f, 20f), 0.8f);
            SliderBarra(filas.transform.Find("FilaSensibilidad"), "Slider",
                        new Vector2(1f, 0.5f), new Vector2(-10f, 0f), new Vector2(400f, 20f), 1f, 0.1f, 3f);

            // dropdowns
            DropdownFolgen(filas.transform.Find("FilaCalidad"), "Dropdown", "Alta");
            DropdownFolgen(filas.transform.Find("FilaResolucion"), "Dropdown", "1920 x 1080");

            // toggle pantalla completa
            Casilla(filas.transform.Find("FilaPantalla"), "Toggle",
                    new Vector2(1f, 0.5f), new Vector2(-10f, 0f), new Vector2(48f, 48f), true);

            // botones inferiores
            GameObject botones = Nuevo("Botones", panel.transform);
            RT(botones, new Vector2(0.5f, 0f), new Vector2(0f, 44f), new Vector2(820f, 64f));

            Sprite marcoIdle = Sp("btn_frame_idle.png");
            Sprite marcoHover = Sp("btn_frame_hover.png");
            Boton(botones.transform, "btnRestaurar", Espaciar("RESTAURAR"), Texto(600), 24f, FolgenColores.TextoSuave,
                  marcoIdle, marcoHover, new Vector2(0.5f, 0.5f), new Vector2(-270f, 0f), new Vector2(240f, 64f));
            Boton(botones.transform, "btnAplicar", Espaciar("APLICAR"), Texto(600), 24f, FolgenColores.Blanco,
                  marcoHover, marcoHover, new Vector2(0.5f, 0.5f), new Vector2(0f, 0f), new Vector2(240f, 64f));
            Boton(botones.transform, "btnVolver", Espaciar("VOLVER"), Texto(600), 24f, FolgenColores.TextoSuave,
                  marcoIdle, marcoHover, new Vector2(0.5f, 0.5f), new Vector2(270f, 0f), new Vector2(240f, 64f));

            return root.gameObject;
        }

        /// <summary>Dropdown compacto con lista desplegable (canvas anidado para quedar encima).</summary>
        private static void DropdownFolgen(Transform fila, string nombre, string valorInicial)
        {
            GameObject go = Nuevo(nombre, fila);
            RT(go, new Vector2(1f, 0.5f), new Vector2(-10f, 0f), new Vector2(400f, 48f));
            Imagen9(go, Sp("cuadro.png"), FolgenColores.PanelTransp(0.95f), raycast: true);
            go.AddComponent<Button>().transition = Selectable.Transition.ColorTint;

            GameObject etiqueta = Nuevo("Etiqueta", go.transform);
            RT(etiqueta, new Vector2(0f, 0f), new Vector2(18f, 0f), new Vector2(360f, 40f));
            Texto(etiqueta, valorInicial, Texto(600), 24, FolgenColores.Blanco, TextAnchor.MiddleLeft);

            GameObject lista = Nuevo("Lista", go.transform);
            var rt = (RectTransform)lista.transform;
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, -4f);
            rt.sizeDelta = new Vector2(0f, 176f);
            Imagen9(lista, Sp("cuadro.png"), new Color(0.055f, 0.03f, 0.1f, 0.97f));
            lista.SetActive(false); // se abre en runtime desde FolgenDropdown

            Canvas canvasLista = lista.AddComponent<Canvas>();
            canvasLista.overrideSorting = true;
            canvasLista.sortingOrder = 100;
            lista.AddComponent<GraphicRaycaster>();

            FolgenDropdown dd = go.AddComponent<FolgenDropdown>();
            dd.etiqueta = etiqueta.GetComponent<Text>();
            dd.lista = rt;
            dd.fuenteLista = Texto(600);
            dd.tamanoFuenteLista = 24;
            dd.spriteFila = Sp("cuadro.png");
        }

        // ================= 5. PANTALLA DE CARGA =================

        public static GameObject ConstruirCarga()
        {
            Canvas root = BasePantalla("PantallaCarga", 15);
            root.gameObject.AddComponent<LoadingScreenController>();
            Imagen(root.gameObject, Sp("loading_bg.png"), FolgenColores.Blanco, raycast: true);

            GameObject logo = Nuevo("LblLogo", root.transform);
            RT(logo, new Vector2(0f, 1f), new Vector2(48f, -42f), new Vector2(700f, 90f));
            Text tLogo = Texto(logo, "FOLGEN <color=#FF2D9B>21</color>", Titulo(900), 72, FolgenColores.Blanco, TextAnchor.LowerLeft);

            GameObject sub = Nuevo("LblSub", root.transform);
            RT(sub, new Vector2(0f, 1f), new Vector2(54f, -140f), new Vector2(700f, 34f));
            Texto(sub, Espaciar("FUERA DEL PRONÓSTICO"), Texto(600), 24, FolgenColores.TextoSuave, TextAnchor.MiddleLeft);

            GameObject bloque = Nuevo("Bloque", root.transform);
            RT(bloque, new Vector2(1f, 0f), new Vector2(-110f, 120f), new Vector2(620f, 230f));

            GameObject titulo = Nuevo("LblTitulo", bloque.transform);
            RT(titulo, new Vector2(0f, 1f), new Vector2(0f, 0f), new Vector2(620f, 60f));
            Texto(titulo, Espaciar("CARGANDO..."), Titulo(700), 46, FolgenColores.Blanco, TextAnchor.MiddleLeft);

            GameObject fila = Nuevo("FilaProgreso", bloque.transform);
            RT(fila, new Vector2(0f, 1f), new Vector2(0f, -88f), new Vector2(620f, 34f));

            GameObject track = Nuevo("Track", fila.transform);
            RT(track, new Vector2(0f, 0.5f), new Vector2(0f, 0f), new Vector2(460f, 14f));
            Imagen9(track, Sp("cuadro.png"), new Color(0.10f, 0.06f, 0.18f, 0.94f));

            GameObject fill = Nuevo("Fill", track.transform);
            var rtFill = (RectTransform)fill.transform;
            rtFill.anchorMin = Vector2.zero; rtFill.anchorMax = Vector2.one;
            rtFill.pivot = new Vector2(0f, 0.5f);
            rtFill.offsetMin = new Vector2(2f, 2f);
            rtFill.offsetMax = new Vector2(-2f, -2f);
            Image imgFill = Imagen(fill, Sp("bar_fill_cian.png"), FolgenColores.Blanco);
            imgFill.type = Image.Type.Filled;
            imgFill.fillMethod = Image.FillMethod.Horizontal;
            imgFill.fillAmount = 0f;

            GameObject pct = Nuevo("LblPorcentaje", fila.transform);
            RT(pct, new Vector2(1f, 0.5f), new Vector2(0f, 0f), new Vector2(140f, 34f));
            Texto(pct, "0%", Titulo(700), 30, FolgenColores.Blanco, TextAnchor.MiddleRight);

            GameObject tip = Nuevo("Tip", bloque.transform);
            RT(tip, new Vector2(0f, 1f), new Vector2(0f, -148f), new Vector2(620f, 64f));
            Imagen9(tip, Sp("cuadro.png"), FolgenColores.PanelTransp(0.85f));
            AcentoIzquierdo(tip, FolgenColores.Magenta);

            GameObject icono = Nuevo("Icono", tip.transform);
            RT(icono, new Vector2(0f, 0.5f), new Vector2(16f, 0f), new Vector2(30f, 30f));
            Imagen(icono, Sp("icon_info.png"), FolgenColores.Blanco);

            GameObject consejo = Nuevo("LblConsejo", tip.transform);
            RT(consejo, new Vector2(0f, 0f), new Vector2(60f, 0f), new Vector2(545f, 64f));
            Text tConsejo = Texto(consejo, "Consejo: Combina golpes basicos con tus habilidades para ganar ventaja.",
                                  Texto(500), 23, FolgenColores.Blanco, TextAnchor.MiddleLeft);
            tConsejo.horizontalOverflow = HorizontalWrapMode.Wrap;
            tConsejo.verticalOverflow = VerticalWrapMode.Overflow;

            return root.gameObject;
        }

        private static Color HexColor(string hex) => FolgenColores.Hex(hex);
    }
}
