using UnityEngine;
using Folgen21.Ugui;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace Folgen21.Ugui.Demo
{
    /// <summary>
    /// Driver de demostracion (uGUI): crea camara, luz, suelo y al rival, y anima el HUD
    /// con datos falsos para que puedas probar todo el paquete sin tu juego.
    /// Controles de la demo:
    ///   - Q / E / R: activan el enfriamiento visual de cada habilidad
    ///   - H: recibe daño (baja la barra de vida)
    ///   - ESC: pausa (gestionado por UIManager)
    /// La mision cambia sola de MOVIMIENTO a HABILIDADES a los ~9 segundos.
    /// </summary>
    public class DemoDriver : MonoBehaviour
    {
        public GameplayHUDController hud;

        private Transform _rival;
        private Camera _camaraPrincipal;
        private RenderTexture _texturaMinimapa;

        private float _cronometro;
        private float _vida = 1f, _energia = 1f;
        private bool _faseHabilidades;
        private float _radioOrbita = 45f;
        private float _anguloOrbita;
        private readonly float[] _enfriamientos = new float[4];

        private void Start()
        {
            // --- camara principal orbitante ---
            var goCamara = new GameObject("DemoCamara");
            _camaraPrincipal = goCamara.AddComponent<Camera>();
            _camaraPrincipal.tag = "MainCamera";
            _camaraPrincipal.fieldOfView = 60f;
            _camaraPrincipal.backgroundColor = new Color(0.09f, 0.05f, 0.16f);
            _camaraPrincipal.clearFlags = CameraClearFlags.SolidColor;

            // --- suelo de referencia ---
            var suelo = GameObject.CreatePrimitive(PrimitiveType.Plane);
            suelo.name = "SueloDemo";
            suelo.transform.localScale = new Vector3(4f, 1f, 4f);

            // --- rival del combate (marcador de mundo + objetivo de la camara) ---
            _rival = GameObject.CreatePrimitive(PrimitiveType.Capsule).transform;
            _rival.name = "RivalDemo";
            _rival.position = new Vector3(27f, 1f, 34f);

            // --- luz direccional ---
            var goLuz = new GameObject("LuzDemo");
            goLuz.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
            var luz = goLuz.AddComponent<Light>();
            luz.type = LightType.Directional;
            luz.intensity = 1.1f;

            // --- camara del minimapa (cenital, Norte = +Z) ---
            _texturaMinimapa = new RenderTexture(256, 256, 16);
            var goMinimapa = new GameObject("DemoCamaraMinimapa");
            var camMinimapa = goMinimapa.AddComponent<Camera>();
            camMinimapa.orthographic = true;
            camMinimapa.orthographicSize = 30f;
            camMinimapa.clearFlags = CameraClearFlags.SolidColor;
            camMinimapa.backgroundColor = new Color(0.08f, 0.05f, 0.15f);
            camMinimapa.transform.position = new Vector3(0f, 60f, 0f);
            camMinimapa.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            camMinimapa.targetTexture = _texturaMinimapa;

            // --- conectar el HUD ---
            if (hud != null)
            {
                hud.SetTexturaMinimapa(_texturaMinimapa);
                hud.SetJugador("JHOEL", 1);
                hud.SetVida(1f);
                hud.SetEnergia(1f);
                hud.SetCantidadItem(3, 3);
                hud.SetMision("COMBATE: MOVIMIENTO", $"Camina y esprinta hacia tu rival ({Mathf.RoundToInt(_radioOrbita)} m)");
                hud.MostrarTip("Acércate a tu rival y usa tus habilidades.");
            }

            // hay "partida guardada" en la demo para activar CONTINUAR
            MainMenuController.MarcarGuardadoExistente(true);
        }

        private void Update()
        {
            if (hud == null) return;
            float dt = Time.unscaledDeltaTime;
            _cronometro += dt;

            // --- camara: orbita al rival y se acerca durante la fase de movimiento ---
            _anguloOrbita += dt * 9f;
            if (!_faseHabilidades) _radioOrbita = Mathf.Lerp(45f, 14f, Mathf.Clamp01(_cronometro / 9f));
            Vector3 posCamara = new Vector3(Mathf.Cos(_anguloOrbita * Mathf.Deg2Rad) * _radioOrbita, 3.5f, Mathf.Sin(_anguloOrbita * Mathf.Deg2Rad) * _radioOrbita);
            _camaraPrincipal.transform.position = posCamara;
            _camaraPrincipal.transform.LookAt(_rival.position + Vector3.up * 1.2f);

            // --- vida y energia oscilando (H recibe daño) ---
            _vida = Mathf.Clamp01(0.62f + 0.38f * Mathf.Sin(_cronometro * 0.9f) - (PresionoTecla(KeyCode.H) ? 0.05f : 0f));
            _energia = Mathf.Clamp01(0.5f + 0.5f * Mathf.Sin(_cronometro * 1.7f + 1f));
            hud.SetVida(_vida);
            hud.SetEnergia(_energia);

            // --- transicion de fase a los 9 segundos ---
            if (!_faseHabilidades && _cronometro > 9f)
            {
                _faseHabilidades = true;
                hud.SetMision("COMBATE: HABILIDADES", "Usa Q, E y R para golpear a tu rival");
                hud.MostrarTip("¡Combina golpes y habilidades para ganar!");
            }

            // --- enfriamientos de habilidades con Q / E / R ---
            if (PresionoTecla(KeyCode.Q)) _enfriamientos[0] = 1f;
            if (PresionoTecla(KeyCode.E)) _enfriamientos[1] = 1f;
            if (PresionoTecla(KeyCode.R)) _enfriamientos[2] = 0.5f;
            for (int i = 0; i < 4; i++)
            {
                if (_enfriamientos[i] > 0f)
                {
                    _enfriamientos[i] = Mathf.Max(0f, _enfriamientos[i] - dt / 3f);
                    hud.SetEnfriamiento(i, _enfriamientos[i]);
                }
            }

            // --- minimapa y marcador de mundo (el rival) ---
            float rotacionHaciaRival = Mathf.Atan2(_rival.position.x, _rival.position.z) * Mathf.Rad2Deg;
            hud.SetRotacionFlecha(rotacionHaciaRival);
            hud.SetMarcadorMinimapa(hud.CalcularOffsetMinimapa(Vector3.zero, _rival.position, 100f / 30f, 0f));

            // la distancia al rival se actualiza en el texto del objetivo
            if (!_faseHabilidades)
            {
                float distancia = Vector3.Distance(Vector3.zero, _rival.position);
                hud.SetMision("COMBATE: MOVIMIENTO", $"Camina y esprinta hacia tu rival ({Mathf.RoundToInt(distancia)} m)");
            }
        }

        // ---------- entrada dual (New Input System o Legacy) ----------

        private static bool PresionoTecla(KeyCode tecla)
        {
#if ENABLE_INPUT_SYSTEM
            var teclado = Keyboard.current;
            if (teclado != null)
            {
                switch (tecla)
                {
                    case KeyCode.Q: return teclado.qKey.wasPressedThisFrame;
                    case KeyCode.E: return teclado.eKey.wasPressedThisFrame;
                    case KeyCode.R: return teclado.rKey.wasPressedThisFrame;
                    case KeyCode.H: return teclado.hKey.wasPressedThisFrame;
                }
            }
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKeyDown(tecla);
#endif
#pragma warning disable CS0162
            return false;
#pragma warning restore CS0162
        }
    }
}
