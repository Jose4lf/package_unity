using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Dropdown compacto estilo Folgen 21 (usado en AJUSTES para Calidad y Resolucion).
    /// El boton principal muestra el valor actual; al pulsarlo despliega la lista
    /// de opciones construida en runtime (sin ScrollRect, apto para listas cortas).
    /// </summary>
    public class FolgenDropdown : MonoBehaviour
    {
        [Header("Referencias (las asigna UIFactory)")]
        public Text etiqueta;
        public RectTransform lista;
        public Font fuenteLista;
        public int tamanoFuenteLista = 24;
        public Sprite spriteFila;

        /// <summary>Se dispara al elegir una opcion (indice).</summary>
        public event Action<int> OnCambio;

        private readonly List<string> _opciones = new List<string>();
        private int _index;
        private bool _abierto;
        private Button _boton;

        /// <summary>Indice de la opcion seleccionada.</summary>
        public int Index
        {
            get => _index;
            set
            {
                _index = Mathf.Clamp(value, 0, Mathf.Max(0, _opciones.Count - 1));
                RefrescarEtiqueta();
            }
        }

        /// <summary>Configura las opciones y el valor inicial.</summary>
        public void Configurar(List<string> opciones, int indiceInicial)
        {
            _opciones.Clear();
            _opciones.AddRange(opciones);
            Index = indiceInicial;
        }

        /// <summary>Texto de la opcion seleccionada (o vacio si no hay).</summary>
        public string TextoActual => (_index >= 0 && _index < _opciones.Count) ? _opciones[_index] : string.Empty;

        private void Awake()
        {
            _boton = GetComponent<Button>();
            if (_boton != null) _boton.onClick.AddListener(Alternar);
            if (lista != null) lista.gameObject.SetActive(false);
        }

        private void Alternar()
        {
            _abierto = !_abierto;
            if (lista != null) lista.gameObject.SetActive(_abierto);
            if (_abierto) ConstruirOpciones();
        }

        private void ConstruirOpciones()
        {
            // limpia entradas anteriores
            for (int i = lista.childCount - 1; i >= 0; i--)
                DestroyImmediate(lista.GetChild(i).gameObject);

            float altoFila = 44f;
            float ancho = lista.rect.width > 1f ? lista.rect.width : 400f;
            lista.sizeDelta = new Vector2(ancho, Mathf.Max(1, _opciones.Count) * altoFila);

            for (int i = 0; i < _opciones.Count; i++)
            {
                int indice = i; // captura para el closure
                GameObject fila = new GameObject("Opcion_" + i, typeof(RectTransform), typeof(Image), typeof(Button), typeof(LayoutElement));
                fila.transform.SetParent(lista, false);

                var rt = (RectTransform)fila.transform;
                rt.anchorMin = new Vector2(0f, 1f);
                rt.anchorMax = new Vector2(1f, 1f);
                rt.pivot = new Vector2(0.5f, 1f);
                rt.anchoredPosition = new Vector2(0f, -i * altoFila);
                rt.sizeDelta = new Vector2(0f, altoFila);

                Image img = fila.GetComponent<Image>();
                img.sprite = spriteFila;
                img.type = Image.Type.Sliced;
                img.color = (i == _index)
                    ? FolgenColores.ConAlfa(FolgenColores.PanelBorde, 0.95f)
                    : FolgenColores.PanelTransp(0.95f);

                Text txt = CrearTextoFila(fila, _opciones[i]);
                txt.font = fuenteLista;
                txt.fontSize = tamanoFuenteLista;
                txt.color = (i == _index) ? FolgenColores.Cyan : FolgenColores.Blanco;

                Button btn = fila.GetComponent<Button>();
                btn.transition = Selectable.Transition.ColorTint;
                btn.onClick.AddListener(() => Elegir(indice));
            }
        }

        private Text CrearTextoFila(GameObject padre, string contenido)
        {
            GameObject go = new GameObject("Texto", typeof(RectTransform), typeof(Text));
            go.transform.SetParent(padre.transform, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(18f, 0f);
            rt.offsetMax = new Vector2(-18f, 0f);
            Text t = go.GetComponent<Text>();
            t.text = contenido;
            t.alignment = TextAnchor.MiddleLeft;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            return t;
        }

        private void Elegir(int indice)
        {
            _index = Mathf.Clamp(indice, 0, Mathf.Max(0, _opciones.Count - 1));
            RefrescarEtiqueta();
            _abierto = false;
            if (lista != null) lista.gameObject.SetActive(false);
            OnCambio?.Invoke(_index);
        }

        private void RefrescarEtiqueta()
        {
            if (etiqueta != null) etiqueta.text = TextoActual;
        }
    }
}
