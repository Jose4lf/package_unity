using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Controlador del HUD de combate (juego de peleas), version uGUI.
    /// Todo el contenido se actualiza por API publica, no depende de tu gameplay:
    /// llamalo desde tus sistemas de vida, combate, rondas, etc.
    ///
    ///     hud.SetVida(0.75f);
    ///     hud.SetEnergia(0.5f);
    ///     hud.SetMision("COMBATE 1", "Derrota a tu rival");
    ///     hud.SetEnfriamiento(0, 0.4f);
    ///
    /// Elementos del HUD (los crea UIFactory): barras de vida/energia, panel de
    /// combate, controles (caminar, sprintar, habilidades), minimapa, caja de
    /// consejos, marcador de rival y 4 slots de habilidades Q/E/R/I.
    /// </summary>
    public class GameplayHUDController : UIScreen
    {
        [Header("Marcador del rival en el mundo (opcional)")]
        [Tooltip("Transform del rival; si esta asignado, el diamante dorado se posiciona automaticamente sobre el.")]
        public Transform objetivoMundo;

        [Tooltip("Altura (en metros) a la que flota el marcador sobre el rival.")]
        public float alturaMarcador = 2f;

        // --- Referencias de UI (se resuelven por nombre al iniciar) ---
        private Text _lblNombre, _lblNivel;
        private Text _lblMisionTitulo, _lblMisionObjetivo;
        private Text _lblTip;
        private Text _lblDistancia;
        private Image _fillVida, _fillEnergia;
        private Image[] _skillEnf;
        private Image[] _skillIconos;
        private Text[] _skillCantidades;
        private CanvasGroup _cajaTip;
        private RawImage _imgMinimapa;
        private RectTransform _flechaJugador, _marcadorMinimapa, _marcadorMundo;
        private Canvas _canvas;

        private float _tipOcultarEn = -1f;
        private Camera _camaraPrincipal;

        private void Start()
        {
            _canvas = GetComponent<Canvas>();

            _lblNombre        = Hijo<Text>("Jugador/Datos/LblNombre");
            _lblNivel         = Hijo<Text>("Jugador/Retrato/Nivel");
            _fillVida         = Hijo<Image>("Jugador/Datos/BarraVida/Fill");
            _fillEnergia      = Hijo<Image>("Jugador/Datos/BarraEnergia/Fill");
            _lblMisionTitulo  = Hijo<Text>("Mision/LblTitulo");
            _lblMisionObjetivo = Hijo<Text>("Mision/LblObjetivo");
            _lblTip           = Hijo<Text>("Tip/LblTip");
            _cajaTip          = Hijo<CanvasGroup>("Tip");
            _imgMinimapa      = Hijo<RawImage>("Minimapa/Mapa");
            _flechaJugador    = Hijo<RectTransform>("Minimapa/Flecha");
            _marcadorMinimapa = Hijo<RectTransform>("Minimapa/Marcador");
            _marcadorMundo    = Hijo<RectTransform>("MarcadorMundo");
            _lblDistancia     = Hijo<Text>("MarcadorMundo/LblDistancia");

            _skillEnf = new Image[4];
            _skillIconos = new Image[4];
            _skillCantidades = new Text[4];
            for (int i = 0; i < 4; i++)
            {
                string ruta = $"Skills/Slot{i}";
                _skillEnf[i]       = Hijo<Image>($"{ruta}/Enfriamiento");
                _skillIconos[i]    = Hijo<Image>($"{ruta}/Icono");
                _skillCantidades[i] = Hijo<Text>($"{ruta}/Cantidad");

                if (_skillEnf[i] != null) _skillEnf[i].fillAmount = 0f;
                if (_skillCantidades[i] != null) _skillCantidades[i].text = "";
            }

            if (_cajaTip != null) _cajaTip.alpha = 1f;
            if (_marcadorMundo != null) _marcadorMundo.gameObject.SetActive(false);
        }

        private void Update()
        {
            // ocultar el consejo con fundido
            if (_cajaTip != null && _tipOcultarEn > 0f && Time.unscaledTime >= _tipOcultarEn)
            {
                _tipOcultarEn = -1f;
                _cajaTip.alpha = 0f;
            }

            if (objetivoMundo != null && _marcadorMundo != null)
                ActualizarMarcadorMundo();
        }

        // ================= API PUBLICA =================

        /// <summary>Nombre y nivel del jugador.</summary>
        public void SetJugador(string nombre, int nivel)
        {
            if (_lblNombre != null) _lblNombre.text = nombre;
            if (_lblNivel != null) _lblNivel.text = nivel.ToString();
        }

        /// <summary>Vida en rango 0..1.</summary>
        public void SetVida(float fraccion)
        {
            if (_fillVida != null) _fillVida.fillAmount = Mathf.Clamp01(fraccion);
        }

        /// <summary>Energia (barra de habilidades) en rango 0..1.</summary>
        public void SetEnergia(float fraccion)
        {
            if (_fillEnergia != null) _fillEnergia.fillAmount = Mathf.Clamp01(fraccion);
        }

        /// <summary>Texto del combate mostrado bajo el retrato.</summary>
        public void SetMision(string titulo, string objetivo)
        {
            if (_lblMisionTitulo != null) _lblMisionTitulo.text = titulo;
            if (_lblMisionObjetivo != null) _lblMisionObjetivo.text = objetivo;
        }

        /// <summary>Muestra un consejo temporal en la caja derecha.</summary>
        public void MostrarTip(string texto, float segundos = 4f)
        {
            if (_lblTip != null) _lblTip.text = texto;
            if (_cajaTip != null)
            {
                _cajaTip.alpha = 1f;
                _tipOcultarEn = Time.unscaledTime + Mathf.Max(0.1f, segundos);
            }
        }

        /// <summary>Textura del minimapa (RenderTexture de tu camara cenital).</summary>
        public void SetTexturaMinimapa(Texture textura)
        {
            if (_imgMinimapa != null)
            {
                _imgMinimapa.texture = textura;
                _imgMinimapa.enabled = textura != null;
            }
        }

        /// <summary>
        /// Posicion del marcador dorado sobre el minimapa, en pixeles respecto al centro
        /// (positivo X derecha, positivo Y abajo). Se recorta automaticamente al borde del circulo.
        /// </summary>
        public void SetMarcadorMinimapa(Vector2 offsetRespectoAlCentro)
        {
            if (_marcadorMinimapa == null) return;
            float radio = 78f;
            Vector2 v = offsetRespectoAlCentro;
            float modulo = v.magnitude;
            if (modulo > radio) v = v / modulo * radio;
            _marcadorMinimapa.anchoredPosition = v;
        }

        /// <summary>Rotacion de la flecha del jugador en el minimapa (grados, 0 = arriba/Norte, sentido horario).</summary>
        public void SetRotacionFlecha(float grados)
        {
            if (_flechaJugador != null)
                _flechaJugador.localEulerAngles = new Vector3(0f, 0f, -grados);
        }

        /// <summary>Cambia el sprite de un slot de habilidad (0=Q, 1=E, 2=R, 3=I).</summary>
        public void SetIconoSkill(int indice, Sprite sprite)
        {
            if (indice < 0 || indice > 3 || _skillIconos[indice] == null) return;
            _skillIconos[indice].sprite = sprite;
        }

        /// <summary>Enfriamiento visual de un slot (0 = listo, 1 = totalmente oscurecido).</summary>
        public void SetEnfriamiento(int indice, float fraccion)
        {
            if (indice < 0 || indice > 3) return;
            float f = Mathf.Clamp01(fraccion);
            if (_skillEnf[indice] != null) _skillEnf[indice].fillAmount = f;
            if (_skillIconos[indice] != null)
            {
                Color c = _skillIconos[indice].color;
                c.a = 1f - 0.55f * f;
                _skillIconos[indice].color = c;
            }
        }

        /// <summary>Cantidad visible en el slot de items (0 oculta el contador).</summary>
        public void SetCantidadItem(int indice, int cantidad)
        {
            if (indice < 0 || indice > 3 || _skillCantidades[indice] == null) return;
            _skillCantidades[indice].text = cantidad > 0 ? cantidad.ToString() : string.Empty;
        }

        // ================= Marcador del rival =================

        /// <summary>Distancia del marcador al rival en el minimapa (lo llama tu sistema o la demo).</summary>
        public Vector2 CalcularOffsetMinimapa(Vector3 posicionJugador, Vector3 posicionObjetivo, float escalaPixelesPorMetro = 0.9f, float rotacionJugadorGrados = 0f)
        {
            Vector3 delta = posicionObjetivo - posicionJugador;
            // gira el delta al espacio relativo de la flecha (Norte arriba = -Z hacia arriba)
            float rad = -rotacionJugadorGrados * Mathf.Deg2Rad;
            Vector2 plano = new Vector2(delta.x, delta.z);
            Vector2 rotado = new Vector2(
                plano.x * Mathf.Cos(rad) - plano.y * Mathf.Sin(rad),
                plano.x * Mathf.Sin(rad) + plano.y * Mathf.Cos(rad));
            // Y del minimapa crece hacia abajo => invertir Z
            return new Vector2(rotado.x * escalaPixelesPorMetro, -rotado.y * escalaPixelesPorMetro);
        }

        private void ActualizarMarcadorMundo()
        {
            if (_canvas == null) return;
            if (_camaraPrincipal == null) _camaraPrincipal = Camera.main;
            if (_camaraPrincipal == null) return;

            Vector3 mundo = objetivoMundo.position + Vector3.up * alturaMarcador;
            Vector3 pantalla = _camaraPrincipal.WorldToScreenPoint(mundo);

            if (pantalla.z <= 0f)
            {
                _marcadorMundo.gameObject.SetActive(false);
                return;
            }

            // Canvas en Screen Space Overlay: camara = null para ScreenPointToLocalPointInRectangle
            RectTransform areaCanvas = (RectTransform)_canvas.transform;
            Vector2 local;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(areaCanvas, pantalla, null, out local);

            _marcadorMundo.gameObject.SetActive(true);
            _marcadorMundo.anchoredPosition = local;

            float distancia = Vector3.Distance(_camaraPrincipal.transform.position, objetivoMundo.position);
            if (_lblDistancia != null) _lblDistancia.text = $"{Mathf.RoundToInt(distancia)} m";
        }
    }
}
