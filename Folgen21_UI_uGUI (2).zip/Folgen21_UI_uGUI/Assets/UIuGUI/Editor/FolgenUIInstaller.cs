using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using Folgen21.Ugui.EditorTools;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace Folgen21.Ugui.EditorTools
{
    /// <summary>
    /// Instalador en 1 clic del paquete uGUI de Folgen 21:
    /// 1. Configura el arte como Sprites (con bordes 9-slice donde toca).
    /// 2. Construye las 5 pantallas y las guarda como prefabs editables.
    /// 3. Crea la escena de demostracion con EventSystem + UIRoot + las 5 pantallas
    ///    + DemoDriver, y la agrega a Build Settings.
    /// Menu: Tools → Folgen 21 UI (uGUI) → 1. Instalar todo
    /// </summary>
    public static class FolgenUIInstaller
    {
        private const string Raiz = UIFactory.RaizAssets;

        // nombres de sprite y borde 9-slice (x, y, z, w) en pixeles
        private static readonly (string archivo, Vector4 borde)[] Bordes =
        {
            ("btn_frame_idle.png",  new Vector4(60f, 50f, 60f, 50f)),
            ("btn_frame_hover.png", new Vector4(60f, 50f, 60f, 50f)),
            ("cuadro.png",          new Vector4(12f, 12f, 12f, 12f)),
        };

        [MenuItem("Tools/Folgen 21 UI (uGUI)/1. Instalar todo (1 clic)", priority = 1)]
        public static void InstalarTodo()
        {
            EditorUtility.DisplayProgressBar("Folgen 21 UI (uGUI)", "Configurando sprites...", 0.1f);
            try
            {
                ConfigurarSprites();
                AssetDatabase.Refresh();

                EditorUtility.DisplayProgressBar("Folgen 21 UI (uGUI)", "Construyendo prefabs de las 5 pantallas...", 0.4f);
                UIFactory.ConstruirYGuardarTodo();
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                EditorUtility.DisplayProgressBar("Folgen 21 UI (uGUI)", "Creando escena de demostracion...", 0.75f);
                CrearEscenaDemo();

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            Debug.Log("[Folgen21] Instalacion uGUI completada.\n" +
                      "Abre Assets/UIuGUI/Demo/Demo_FolgenUI.unity y pulsa Play para probar la demo de combate.");
        }

        [MenuItem("Tools/Folgen 21 UI (uGUI)/2. Recrear prefabs de pantallas", priority = 2)]
        public static void RecrearPrefabs()
        {
            ConfigurarSprites();
            AssetDatabase.Refresh();
            UIFactory.ConstruirYGuardarTodo();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("[Folgen21] Prefabs recreados en " + UIFactory.RaizPrefabs +
                      ". Si ya tenias la escena demo montada, reemplaza las pantallas por los nuevos prefabs.");
        }

        // ---------------- sprites ----------------

        private static void ConfigurarSprites()
        {
            if (!Directory.Exists(UIFactory.RaizArt))
            {
                Debug.LogError($"[Folgen21] No existe la carpeta {UIFactory.RaizArt}. Importa el paquete completo.");
                return;
            }

            foreach (string ruta in Directory.GetFiles(UIFactory.RaizArt, "*.png"))
            {
                string rutaAsset = ruta.Replace('\\', '/');
                TextureImporter ti = AssetImporter.GetAtPath(rutaAsset) as TextureImporter;
                if (ti == null) continue;

                bool cambio = false;
                if (ti.textureType != TextureImporterType.Sprite)
                {
                    ti.textureType = TextureImporterType.Sprite;
                    cambio = true;
                }
                if (ti.spriteImportMode != SpriteImportMode.Single)
                {
                    ti.spriteImportMode = SpriteImportMode.Single;
                    cambio = true;
                }
                if (ti.mipmapEnabled) { ti.mipmapEnabled = false; cambio = true; }
                if (ti.filterMode != FilterMode.Bilinear) { ti.filterMode = FilterMode.Bilinear; cambio = true; }
                if (ti.maxTextureSize < 2048) { ti.maxTextureSize = 2048; cambio = true; }

                string nombre = Path.GetFileName(rutaAsset);
                Vector4 borde = Vector4.zero;
                foreach (var b in Bordes)
                    if (b.archivo == nombre) { borde = b.borde; break; }
                if (ti.spriteBorder != borde) { ti.spriteBorder = borde; cambio = true; }

                if (cambio)
                {
                    ti.SaveAndReimport();
                    Debug.Log("[Folgen21] Sprite configurado: " + rutaAsset);
                }
            }
        }

        // ---------------- escena demo ----------------

        private static void CrearEscenaDemo()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // --- EventSystem (compatible con ambos input systems) ---
            GameObject eventSystem = new GameObject("EventSystem");
            eventSystem.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
            eventSystem.AddComponent<InputSystemUIInputModule>();
#else
            eventSystem.AddComponent<StandaloneInputModule>();
#endif

            // --- UIRoot con el coordinador ---
            GameObject uiRoot = new GameObject("UIRoot");
            UIManager manager = uiRoot.AddComponent<UIManager>();
            manager.modoDemo = true; // la demo simula la carga; desactivalo en tu juego real

            // --- las 5 pantallas (prefabs) ---
            string[] prefabs =
            {
                "PantallaMenuPrincipal.prefab",
                "PantallaHUD.prefab",
                "PantallaPausa.prefab",
                "PantallaAjustes.prefab",
                "PantallaCarga.prefab",
            };
            foreach (string p in prefabs)
            {
                string ruta = $"{UIFactory.RaizPrefabs}/{p}";
                GameObject asset = AssetDatabase.LoadAssetAtPath<GameObject>(ruta);
                if (asset == null)
                {
                    Debug.LogError("[Folgen21] Falta el prefab " + ruta);
                    continue;
                }
                PrefabUtility.InstantiatePrefab(asset, uiRoot.transform);
            }

            // --- driver de la demo de combate ---
            GameObject demo = new GameObject("DemoDriver");
            DemoDriver driver = demo.AddComponent<DemoDriver>();
            driver.hud = uiRoot.GetComponentInChildren<GameplayHUDController>(true);

            // --- guardar escena ---
            string carpeta = $"{Raiz}/Demo";
            if (!Directory.Exists(carpeta)) Directory.CreateDirectory(carpeta);
            string rutaEscena = $"{carpeta}/Demo_FolgenUI.unity";
            EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), rutaEscena);

            // --- agregar a Build Settings ---
            var escenas = new System.Collections.Generic.List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            int yaEsta = escenas.FindIndex(s => s.path == rutaEscena);
            if (yaEsta >= 0) escenas[yaEsta] = new EditorBuildSettingsScene(rutaEscena, true);
            else escenas.Add(new EditorBuildSettingsScene(rutaEscena, true));
            EditorBuildSettings.scenes = escenas.ToArray();

            Debug.Log("[Folgen21] Escena demo creada: " + rutaEscena + " (agregada a Build Settings)");
            Selection.activeObject = AssetDatabase.LoadAssetAtPath<SceneAsset>(rutaEscena);
        }
    }
}
