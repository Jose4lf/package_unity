using UnityEngine;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Paleta de colores del tema cyberpunk de Folgen 21.
    /// Equivalente a las variables --c-* de la version UI Toolkit.
    /// UIFactory los usa al construir los prefabs; puedes retocar los
    /// componentes de cada prefab despues de instalarlos.
    /// </summary>
    public static class FolgenColores
    {
        public static readonly Color Fondo        = Hex("120A1F");
        public static readonly Color Panel        = Hex("1C1030");
        public static readonly Color PanelBorde   = Hex("3A2A5E");
        public static readonly Color Magenta      = Hex("FF2D9B");
        public static readonly Color MagentaClaro = Hex("FF5FC1");
        public static readonly Color Cyan         = Hex("35D6FF");
        public static readonly Color Blanco       = Hex("FFFFFF");
        public static readonly Color TextoSuave   = Hex("B9AFD6");
        public static readonly Color Oro          = Hex("FFD23F");
        public static readonly Color Vida         = Hex("FF3B5C");
        public static readonly Color Energia      = Hex("2FB4FF");

        /// <summary>Panel oscuro semitransparente (cajas del HUD y menus).</summary>
        public static Color PanelTransp(float alpha = 0.85f) => ConAlfa(Panel, alpha);

        public static Color ConAlfa(Color c, float alpha) => new Color(c.r, c.g, c.b, alpha);

        public static Color Hex(string hex)
        {
            hex = hex.TrimStart('#');
            float r = int.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber) / 255f;
            float g = int.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber) / 255f;
            float b = int.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber) / 255f;
            return new Color(r, g, b, 1f);
        }
    }
}
