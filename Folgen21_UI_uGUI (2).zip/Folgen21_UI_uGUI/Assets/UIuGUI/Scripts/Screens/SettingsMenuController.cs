using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Controlador del menu de ajustes (uGUI): musica, efectos, sensibilidad,
    /// calidad grafica, resolucion y pantalla completa.
    /// Guarda todo en PlayerPrefs bajo claves "folgen_*" y aplica al iniciar la app.
    /// Componentes creados por UIFactory: sMusica, sEfectos, sSensibilidad (Slider),
    /// dCalidad, dResolucion (FolgenDropdown), tPantallaCompleta (Toggle),
    /// btnRestaurar, btnAplicar, btnVolver (Button).
    /// </summary>
    public class SettingsMenuController : UIScreen
    {
        public event Action Cerrado;

        // Claves de guardado (mismas que la version UI Toolkit)
        public const string KeyMusica       = "folgen_musica";
        public const string KeyEfectos      = "folgen_efectos";
        public const string KeySensibilidad = "folgen_sensibilidad";
        public const string KeyCalidad      = "folgen_calidad";
        public const string KeyResolucion   = "folgen_resolucion";
        public const string KeyPantalla     = "folgen_pantalla_completa";

        private Slider _sMusica, _sEfectos, _sSensibilidad;
        private FolgenDropdown _dCalidad, _dResolucion;
        private Toggle _tPantallaCompleta;

        private int[] _resAncho, _resAlto;

        private void Start()
        {
            _sMusica          = Hijo<Slider>("Panel/Filas/FilaMusica/Slider");
            _sEfectos         = Hijo<Slider>("Panel/Filas/FilaEfectos/Slider");
            _sSensibilidad    = Hijo<Slider>("Panel/Filas/FilaSensibilidad/Slider");
            _dCalidad         = Hijo<FolgenDropdown>("Panel/Filas/FilaCalidad/Dropdown");
            _dResolucion      = Hijo<FolgenDropdown>("Panel/Filas/FilaResolucion/Dropdown");
            _tPantallaCompleta = Hijo<Toggle>("Panel/Filas/FilaPantalla/Toggle");

            if (_sMusica == null || _sEfectos == null || _sSensibilidad == null ||
                _dCalidad == null || _dResolucion == null || _tPantallaCompleta == null)
                return;

            // Opciones de calidad
            _dCalidad.Configurar(new List<string>(QualitySettings.names), QualitySettings.GetQualityLevel());

            // Resoluciones unicas (anchura x altura)
            var opciones = new List<string>();
            var anchos = new List<int>();
            var altos = new List<int>();
            Resolution resActual = Screen.currentResolution;
            int indiceActual = 0;
            foreach (var r in Screen.resolutions)
            {
                string etiqueta = $"{r.width} x {r.height}";
                int yaEsta = opciones.IndexOf(etiqueta);
                if (yaEsta < 0)
                {
                    if (r.width == resActual.width && r.height == resActual.height) indiceActual = opciones.Count;
                    opciones.Add(etiqueta);
                    anchos.Add(r.width);
                    altos.Add(r.height);
                }
            }
            _dResolucion.Configurar(opciones, indiceActual);
            _resAncho = anchos.ToArray();
            _resAlto = altos.ToArray();

            // Valores guardados
            _sMusica.value       = PlayerPrefs.GetFloat(KeyMusica, 0.8f);
            _sEfectos.value      = PlayerPrefs.GetFloat(KeyEfectos, 0.8f);
            _sSensibilidad.value = PlayerPrefs.GetFloat(KeySensibilidad, 1f);
            _tPantallaCompleta.SetIsOnWithoutNotify(Screen.fullScreenMode != FullScreenMode.Windowed);

            Button btnRestaurar = Hijo<Button>("Panel/Botones/btnRestaurar");
            Button btnAplicar   = Hijo<Button>("Panel/Botones/btnAplicar");
            Button btnVolver    = Hijo<Button>("Panel/Botones/btnVolver");
            if (btnRestaurar != null) btnRestaurar.onClick.AddListener(RestaurarValores);
            if (btnAplicar != null)   btnAplicar.onClick.AddListener(AplicarYGuardar);
            if (btnVolver != null)    btnVolver.onClick.AddListener(() => Cerrado?.Invoke());

            AplicarGuardadoAlIniciar();
        }

        private void RestaurarValores()
        {
            _sMusica.value = 0.8f;
            _sEfectos.value = 0.8f;
            _sSensibilidad.value = 1f;
            _dCalidad.Index = Mathf.Max(0, QualitySettings.names.Length - 1);
            _tPantallaCompleta.SetIsOnWithoutNotify(true);
        }

        private void AplicarYGuardar()
        {
            PlayerPrefs.SetFloat(KeyMusica, _sMusica.value);
            PlayerPrefs.SetFloat(KeyEfectos, _sEfectos.value);
            PlayerPrefs.SetFloat(KeySensibilidad, _sSensibilidad.value);
            PlayerPrefs.SetInt(KeyCalidad, _dCalidad.Index);

            bool pantallaCompleta = _tPantallaCompleta.isOn;
            PlayerPrefs.SetInt(KeyPantalla, pantallaCompleta ? 1 : 0);

            // Calidad grafica
            QualitySettings.SetQualityLevel(_dCalidad.Index, true);

            // Resolucion y modo de pantalla
            int i = Mathf.Clamp(_dResolucion.Index, 0, _resAncho.Length - 1);
            var modo = pantallaCompleta
                ? (Screen.currentResolution.width == _resAncho[i] && Screen.currentResolution.height == _resAlto[i]
                    ? FullScreenMode.FullScreenWindow
                    : FullScreenMode.ExclusiveFullScreen)
                : FullScreenMode.Windowed;
            Screen.SetResolution(_resAncho[i], _resAlto[i], modo);

            // En la demo (sin AudioMixer) el volumen general sigue la musica;
            // en tu juego real conecta estos valores a tu AudioMixer.
            AudioListener.volume = _sMusica.value * 0.5f + _sEfectos.value * 0.5f;

            PlayerPrefs.Save();
        }

        // ---------------- Acceso estatico para tu gameplay ----------------

        /// <summary>Sensibilidad del raton guardada (multiplicador, 0.1 - 3).</summary>
        public static float SensibilidadActual => PlayerPrefs.GetFloat(KeySensibilidad, 1f);

        /// <summary>Volumen de musica guardado (0 - 1).</summary>
        public static float VolumenMusica => PlayerPrefs.GetFloat(KeyMusica, 0.8f);

        /// <summary>Volumen de efectos guardado (0 - 1).</summary>
        public static float VolumenEfectos => PlayerPrefs.GetFloat(KeyEfectos, 0.8f);

        /// <summary>Aplica los ajustes guardados al arrancar la aplicacion.</summary>
        public static void AplicarGuardadoAlIniciar()
        {
            int calidad = PlayerPrefs.GetInt(KeyCalidad, -1);
            if (calidad >= 0 && calidad < QualitySettings.names.Length)
                QualitySettings.SetQualityLevel(calidad, true);

            bool pantalla = PlayerPrefs.GetInt(KeyPantalla, 1) == 1;
            Screen.fullScreenMode = pantalla ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
        }
    }
}
