# Folgen 21 - Paquete de Interfaz uGUI (Unity 6 / Unity UI)

Interfaz completa lista para **Unity 6000.3.28f1 (Unity 6)**, construida 100% con **uGUI (Unity UI / Canvas)**: Canvas, Image, Text, Button, Slider y prefabs editables — fiel al diseño cyberpunk del juego: menú principal, HUD de combate (juego de peleas), menú de pausa, ajustes y pantalla de carga.

> Esta es la versión **uGUI** del paquete (prefabs + Canvas). Si prefieres la versión UI Toolkit (UXML/USS), usa `Folgen21_UI.unitypackage`. Ambas pueden coexistir en el mismo proyecto: este paquete usa el namespace `Folgen21.Ugui` y la carpeta `Assets/UIuGUI`.

---

## 1. Instalación

### Opción A — .unitypackage (recomendada)
1. Doble clic en `Folgen21_UI_uGUI.unitypackage` (o en Unity: **Assets → Import Package → Custom Package...**).
2. En la ventana de importación deja todo marcado y pulsa **Import**.

### Opción B — ZIP
1. Descomprime `Folgen21_UI_uGUI.zip`.
2. Copia la carpeta `Assets/UIuGUI` dentro de la carpeta `Assets` de tu proyecto.
3. Vuelve a Unity y deja que refresque.

> Nota: si tu proyecto ya tenía archivos con los mismos nombres (por ejemplo `UIManager.cs`), **serán reemplazados** por los de este paquete (solo dentro de `Assets/UIuGUI`, no toca otros archivos).

## 2. Configuración en 1 clic

Tras importar, en la barra de Unity:

```
Tools → Folgen 21 UI (uGUI) → 1. Instalar todo (1 clic)
```

Esto hace automáticamente:
- **Configura el arte como Sprites** (bordes 9-slice en marcos de botones y paneles).
- **Construye las 5 pantallas** programáticamente (UIFactory) y las guarda como **prefabs editables** en `Assets/UIuGUI/Prefabs/`:
  `PantallaMenuPrincipal`, `PantallaHUD`, `PantallaPausa`, `PantallaAjustes`, `PantallaCarga`.
- Genera la **escena de demostración** `Assets/UIuGUI/Demo/Demo_FolgenUI.unity` con EventSystem, UIRoot (UIManager), las 5 pantallas montadas y el DemoDriver, y la agrega a Build Settings.

También tienes el menú **2. Recrear prefabs de pantallas** para regenerarlos si los borras o rompes.

## 3. Probar la demo

1. Abre `Assets/UIuGUI/Demo/Demo_FolgenUI.unity`.
2. Pulsa **Play**. Verás el menú principal.
3. **NUEVA PARTIDA** → pantalla de carga con consejos → HUD de combate animado (fase MOVIMIENTO → HABILIDADES).
4. En el HUD: **Q/E/R** muestran el enfriamiento de las habilidades, **H** recibe daño, **ESC** abre la pausa.
5. En la pausa: CONTINUAR, AJUSTES (música, efectos, sensibilidad, calidad, resolución, pantalla completa), MENÚ PRINCIPAL y SALIR.

La escena demo usa `UIManager.modoDemo = true` (carga simulada, sin cambiar de escena). Desactiva esa casilla en tu juego real.

## 4. Integrar en TU juego

### Estructura recomendada
Crea un GameObject `UIRoot` en tu escena con el script `UIManager` y arrastra como hijos los 5 prefabs de `Assets/UIuGUI/Prefabs/`. Cada prefab trae su propio Canvas (Screen Space - Overlay) + CanvasScaler 1920×1080 + controlador:

```
UIRoot                 ← UIManager (quita la casilla modoDemo)
├── PantallaMenuPrincipal
├── PantallaHUD
├── PantallaPausa
├── PantallaAjustes
└── PantallaCarga
```

- En `UIManager` pon `escenaJuego = "TuEscenaDeJuego"` y `escenaMenu = "TuEscenaDeMenu"` (deben estar en Build Settings).
- Solo necesitas **un EventSystem** en la escena (Unity lo crea con `GameObject → UI → Event System` si no existe).
- Asegúrate de que tu cámara principal esté etiquetada **MainCamera** (el marcador del rival la usa).
- La forma más simple para un proyecto pequeño: las 5 pantallas en una única escena persistente con `modoDemo = false` (la carga sí cambia de escena; el HUD se muestra al terminar).

### Conectar tus sistemas al HUD (sin acoplamiento)

```csharp
var hud = FindObjectOfType<Folgen21.Ugui.GameplayHUDController>();

hud.SetJugador("JHOEL", 7);          // nombre y nivel
hud.SetVida(0.75f);                   // vida 0..1 (Image.fillAmount)
hud.SetEnergia(0.5f);                 // energia (barra de habilidades) 0..1
hud.SetMision("COMBATE: MOVIMIENTO", "Camina y esprinta hacia tu rival (45 m)");
hud.MostrarTip("Acércate a tu rival y usa tus habilidades.", 4f);
hud.SetIconoSkill(0, miSprite);       // sprites por codigo (0=Q,1=E,2=R,3=I)
hud.SetEnfriamiento(0, 0.6f);         // enfriamiento visual 0..1
hud.SetCantidadItem(3, 3);            // contador del slot de items

// Marcador dorado sobre el rival (o el objetivo del combate):
hud.objetivoMundo = miTransformDeObjetivo;   // se posiciona y mide solo

// Minimapa: pásale el RenderTexture de tu cámara cenital:
hud.SetTexturaMinimapa(miRenderTexture);
// y cada frame el desplazamiento del marcador:
hud.SetMarcadorMinimapa(hud.CalcularOffsetMinimapa(posJugador, posRival, pixelesPorMetro, rotacionGrados));
hud.SetRotacionFlecha(anguloGrados);
```

### Conectar tus sistemas a los menús

```csharp
var menu = FindObjectOfType<Folgen21.Ugui.MainMenuController>();
menu.NuevaPartidaClicked += TuLogicaDeNuevaPartida;
menu.ContinuarClicked    += TuLogicaDeCargarPartida;

// Para activar el botón CONTINUAR cuando exista guardado:
Folgen21.Ugui.MainMenuController.MarcarGuardadoExistente(true);

var pausa = FindObjectOfType<Folgen21.Ugui.PauseMenuController>();
pausa.MenuPrincipalClicked += TuLogicaDeSalirAlMenu;
```

### Ajustes guardados

Todo se guarda en `PlayerPrefs` con claves `folgen_*` y se aplica al arrancar. Lee los valores desde tu gameplay:

```csharp
float sensibilidad = Folgen21.Ugui.SettingsMenuController.SensibilidadActual;  // multiplicador 0.1-3
float musica  = Folgen21.Ugui.SettingsMenuController.VolumenMusica;            // 0-1
float efectos = Folgen21.Ugui.SettingsMenuController.VolumenEfectos;           // 0-1
```

Conéctalo a tu **AudioMixer**: `mixer.SetFloat("Musica", Mathf.Log10(musica) * 20);`

### Flujo de estado (UIManager)

`EstadoUI`: `MenuPrincipal → Cargando → Jugando ⇄ Pausado → Ajustes`. Notifica cambios:

```csharp
Folgen21.Ugui.UIManager.Instancia.OnCambioEstado += estado => { /* pausa tu audio, desactiva controles, etc. */ };
```

## 5. Herramienta para VER y EDITAR el diseño

Cada pantalla es un **prefab uGUI normal**: ábrelo en modo Prefab (doble clic) o instancialo en una escena y edita rects, colores, sprites y textos desde el Inspector. Los nombres de los elementos están pensados para que los controladores los encuentren (`Hijo<T>("Ruta/Elemento")`) — si renombras algo, actualiza también el controlador.

Adicionalmente el paquete incluye **`preview.html`** (en la raíz del ZIP): ábrelo en cualquier navegador para ver las 5 pantallas con el arte final sin abrir Unity.

## 6. Personalización rápida

| Quiero cambiar... | Edita... |
|---|---|
| Colores del tema | `Scripts/Core/FolgenColores.cs` (+ tinte de cada Image en los prefabs) |
| Fondo del menú / carga | `Art/mainmenu_bg.png`, `Art/loading_bg.png` |
| Retrato del jugador | `Art/portrait_jhoel.png` |
| Iconos de habilidades | `Art/icon_skill_q/e/r.png`, `icon_item.png` |
| Tipografías | `Fonts/*.ttf` (reemplaza con el mismo nombre y recrea los prefabs) |
| Consejos de la carga | `LoadingScreenController.consejos` (Inspector) |
| Controles del HUD (caminar, sprintar, habilidades) | Regenera con `Editor/UIFactory.cs` (método `ConstruirHUD`, sección `FilaControles`) o edita el prefab |
| Regenerar todas las pantallas | `Tools → Folgen 21 UI (uGUI) → 2. Recrear prefabs` |

## 7. Solución de problemas

- **Los sprites se ven como texturas cuadradas**: ejecuta `Tools → Folgen 21 UI (uGUI) → 2. Recrear prefabs` (el instalador configura el importador de texturas).
- **Los botones no responden**: falta un EventSystem en la escena (`GameObject → UI → Event System`), o el módulo de input no coincide con tu *Active Input Handling* (el instalador lo resuelve solo en la demo).
- **Texto en fuente por defecto**: los `.ttf` se importan como *Font* dinámico; si sustituyes fuentes conserva los mismos nombres de archivo y recrea los prefabs.
- **Input System**: el código es dual (`#if ENABLE_INPUT_SYSTEM` / `ENABLE_LEGACY_INPUT_MANAGER`); funciona sin tocar nada en ambos modos de *Active Input Handling*.
- **ESC no abre la pausa**: `UIManager` debe estar en la escena y el estado debe ser `Jugando`.
- **Marcador del rival no aparece**: asigna `hud.objetivoMundo` y verifica que existe una cámara con el tag **MainCamera**.
- **Escena "Gameplay" no encontrada**: agrega tus escenas a *File → Build Settings*.

## 8. Contenido del paquete

```
Assets/UIuGUI/
├── Art/                      ← fondos, retrato, iconos, marcos 9-slice, barras
├── Fonts/                    ← Orbitron (títulos) y Rajdhani (texto), licencia OFL
├── Prefabs/                  ← las 5 pantallas (las crea el instalador)
├── Demo/
│   └── Demo_FolgenUI.unity   ← escena demo (la crea el instalador)
├── Editor/
│   ├── UIFactory.cs          ← construcción programática de las pantallas
│   └── FolgenUIInstaller.cs  ← menú Tools → Folgen 21 UI (uGUI)
├── Scripts/
│   ├── Core/
│   │   ├── UIManager.cs      ← coordinador de flujo y pausa (ESC)
│   │   ├── UIScreen.cs       ← base de todos los controladores
│   │   ├── FolgenColores.cs  ← paleta del tema
│   │   └── FolgenDropdown.cs ← dropdown compacto de los ajustes
│   ├── Screens/              ← MainMenu / GameplayHUD / PauseMenu / SettingsMenu / LoadingScreen
│   └── Demo/DemoDriver.cs    ← demo jugable del HUD de combate
└── README.md
```
