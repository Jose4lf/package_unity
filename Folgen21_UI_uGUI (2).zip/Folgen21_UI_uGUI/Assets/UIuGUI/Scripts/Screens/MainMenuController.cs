using System;
using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Controlador del menu principal (uGUI). Los botones los crea UIFactory con los
    /// nombres: btnNuevaPartida, btnContinuar, btnAjustes, btnSalir, btnEngranaje.
    /// Expone eventos C# para que tu gameplay se conecte sin acoplamiento.
    /// </summary>
    public class MainMenuController : UIScreen
    {
        public event Action NuevaPartidaClicked;
        public event Action ContinuarClicked;
        public event Action AjustesClicked;
        public event Action SalirClicked;

        private const string KeyGuardado = "folgen_tiene_guardado";

        private Button _btnNuevaPartida;
        private Button _btnContinuar;
        private Button _btnAjustes;
        private Button _btnSalir;

        private void Start()
        {
            _btnNuevaPartida = Hijo<Button>("Centro/Botones/btnNuevaPartida");
            _btnContinuar    = Hijo<Button>("Centro/Botones/btnContinuar");
            _btnAjustes      = Hijo<Button>("Centro/Botones/btnAjustes");
            _btnSalir        = Hijo<Button>("Centro/Botones/btnSalir");
            Button btnEngranaje = Hijo<Button>("btnEngranaje");

            if (_btnNuevaPartida != null) _btnNuevaPartida.onClick.AddListener(() => NuevaPartidaClicked?.Invoke());
            if (_btnContinuar != null)    _btnContinuar.onClick.AddListener(() => ContinuarClicked?.Invoke());
            if (_btnAjustes != null)      _btnAjustes.onClick.AddListener(() => AjustesClicked?.Invoke());
            if (_btnSalir != null)        _btnSalir.onClick.AddListener(() => SalirClicked?.Invoke());
            if (btnEngranaje != null)     btnEngranaje.onClick.AddListener(() => AjustesClicked?.Invoke());
        }

        /// <summary>Marca si existe partida guardada (activa/desactiva CONTINUAR).</summary>
        public static void MarcarGuardadoExistente(bool existe)
        {
            if (existe) PlayerPrefs.SetInt(KeyGuardado, 1);
            else PlayerPrefs.DeleteKey(KeyGuardado);
        }

        protected override void OnMostrado()
        {
            // CONTINUAR solo disponible si hay partida guardada
            if (_btnContinuar != null)
                _btnContinuar.interactable = PlayerPrefs.HasKey(KeyGuardado);
        }
    }
}
