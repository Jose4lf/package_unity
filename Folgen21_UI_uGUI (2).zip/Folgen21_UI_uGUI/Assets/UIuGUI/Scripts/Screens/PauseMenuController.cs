using System;
using UnityEngine;
using UnityEngine.UI;

namespace Folgen21.Ugui
{
    /// <summary>
    /// Controlador del menu de pausa (uGUI). UIManager gestiona abrir/cerrar con ESC;
    /// los eventos estan disponibles para conectar logica extra de tu juego.
    /// Botones: btnContinuar, btnAjustes, btnMenuPrincipal, btnSalir.
    /// </summary>
    public class PauseMenuController : UIScreen
    {
        public event Action ContinuarClicked;
        public event Action AjustesClicked;
        public event Action MenuPrincipalClicked;
        public event Action SalirClicked;

        private void Start()
        {
            Button btnContinuar     = Hijo<Button>("Botones/btnContinuar");
            Button btnAjustes       = Hijo<Button>("Botones/btnAjustes");
            Button btnMenuPrincipal = Hijo<Button>("Botones/btnMenuPrincipal");
            Button btnSalir         = Hijo<Button>("Botones/btnSalir");

            if (btnContinuar != null)     btnContinuar.onClick.AddListener(() => ContinuarClicked?.Invoke());
            if (btnAjustes != null)       btnAjustes.onClick.AddListener(() => AjustesClicked?.Invoke());
            if (btnMenuPrincipal != null) btnMenuPrincipal.onClick.AddListener(() => MenuPrincipalClicked?.Invoke());
            if (btnSalir != null)         btnSalir.onClick.AddListener(() => SalirClicked?.Invoke());
        }
    }
}
